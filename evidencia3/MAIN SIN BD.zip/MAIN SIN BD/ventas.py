# Función para gestionar las ventas
from datetime import datetime

def gestionar_ventas(ventas, clientes, destinos):
    while True:   #opciones dentro del submenu
        print("""\n>>> Gestión de Ventas<<<
        1. Registrar venta
        2. Ver estado de la venta
        3. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:  #opcion para registrar una venta
                while True:  # Bucle para pedir un ID válido
                 id_venta = input("\nIngrese el ID de la venta: ")
                 if id_venta in ventas:
                    print("\nError: El ID de la venta ya existe. Por favor, ingrese otro.")
                 else:
                    break  # Si el ID es único, salimos del bucle

                cuit_cliente=int(input("\nIngrese el CUIT del cliente que realiza la compra: "))
                if cuit_cliente not in clientes:
                    print("\nError: El CUIT ingresado no existe en la base de datos de clientes.")
                    continue  # Evita el registro con un CUIT inexistente

                id_destino=input("\nIngrese el ID del destino: ")
                if id_destino not in destinos:
                    print("\nError: El ID de destino ingresado no existe en la base de datos de destinos.")
                    continue #evita el registro con un id_Destino inexistente
                try: 
                    fecha=input("Ingrese la fecha de venta (formato YYYY-MM-DD): ")
                    fecha_venta=datetime.strptime(fecha, "%Y-%m-%d").date()
                except ValueError:
                    print("Formato inválido. Usá YYYY-MM-DD (por ejemplo: 2025-06-03).")
                    continue
                ventas.update({id_venta: {     #agregamos al diccionario teniendo como identificador el cuit
                        "cliente": cuit_cliente,
                        "destino": id_destino,
                        "fecha": fecha_venta,
                        "estado": "activo",
                        "fecha_anulacion": ""}
                        })
                print(f""">>Se registra nueva venta:
                \nID de la venta: {id_venta}
                \nCliente: {cuit_cliente}
                \nDestino: {id_destino}
                \nFecha de la venta: {fecha_venta}
                """)  #mostramos los datos de la venta registrada
                break
            elif opcion_funcion == 2:   #opcion para ver los estados de las ventas
                id_venta=input("Ingrese el ID de la venta que desea ver el estado: ")
                estado_venta=ventas[id_venta]['estado']
                print(f"El estado de la venta: {id_venta}, es {estado_venta}")
                break
            elif opcion_funcion == 3:  #opcion para volver al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")


# Función para consultar las ventas
def consultar_ventas(ventas):
    while True:    #opciones dentro del submenu de consultar ventas
        print("""\n>>> Consulta de Ventas<<< 
        1. Consultar ventas
        2. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:   #opcion de consultar ventas
                print("Mostrando historial de ventas...")
                for id, datos in ventas.items(): # Iteramos sobre los items del diccionario
                    print(f"\nID VENTA: {id} \nCLIENTE: {datos['cliente']} \nDESTINO: {datos['destino']} \nFECHA:{datos['fecha']} \nESTADO:{datos['estado']}")
                break
            elif opcion_funcion == 2:   #opcion para volver al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

