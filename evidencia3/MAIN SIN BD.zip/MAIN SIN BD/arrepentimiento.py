# Función para acceder al botón de arrepentimiento
from datetime import datetime,timedelta
def boton_arrepentimiento(ventas):
    while True:    #opcion para el submenu de arrepentimiento
        print("""\n>>> Botón de Arrepentimiento<<<
        1. Cancelar compra
        2. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:   #opcion para cancelar la compra
                id_venta=input("\nIngrese el ID de la venta que desea cancelar: ")
                if id_venta in ventas:
                    fecha_venta = ventas[id_venta]['fecha']
                else:
                    print("\nError: El ID de venta ingresado no existe.")
                    continue  

                try: 
                    fecha=input("Ingrese la fecha de hoy (formato YYYY-MM-DD): ")
                    fecha_hoy=datetime.strptime(fecha, "%Y-%m-%d").date()
                except ValueError:
                    print("Formato inválido. Usá YYYY-MM-DD (por ejemplo: 2025-06-03).")
                    continue
                fecha_limite = fecha_venta + timedelta(days=5)
                if fecha_hoy <= fecha_limite: 
                    ventas[id_venta]['estado'] = "anulado"
                    ventas[id_venta]['fecha_anulacion'] = fecha
                    print(f"\nCompra con el ID cancelada: {id_venta}")
                else:
                    print("La fecha en la que realiza la cancelación no puede superar los 5 días desde la compra")
                break
            elif opcion_funcion == 2:
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

    