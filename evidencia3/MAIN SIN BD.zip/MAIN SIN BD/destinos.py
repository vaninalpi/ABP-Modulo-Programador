# Función para gestionar los destinos

def gestionar_destinos(destinos):
    while True:  #mostramos opciones disponibles para ejecutar
        print("""\n>>> Gestión de Destinos<<<
        1. Registrar destino
        2. Modificar destino
        3. Eliminar destino
        4. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:  #opcion para registrar un destino
                id_destino=input("Ingrese el ID del destino: ")
                if id_destino in destinos:  #corroboramos que no exista el ID ingresado
                    print("\nEl destino ya existe en la base de datos.")
                else:
                    ciudad_destino=input("Ingrese la ciudad del destino: ")
                    pais_destino=input("Ingrese el pais del destino: ")
                    costo_destino=int(input("Ingrese el costo de base del destino:$ "))
                    destinos.update({id_destino: {     #agregamos al diccionario teniendo como identificador el ID del destino
                        "pais": pais_destino,
                        "ciudad": ciudad_destino,
                        "costo": costo_destino}
                        })
                    print(f""">>Destino registrado como:  
                        \nID: {id_destino}     
                        \nCiudad: {ciudad_destino}
                        \nPais: {pais_destino}
                        \nCosto base del viaje:  {costo_destino}
                    """)  #mostramos los datos que se acaban de registrar
                break
            elif opcion_funcion == 2:  #opcion para modificar un destino
                id_destino=input("Ingrese el ID del destino que desea modificar: ")
                if id_destino in destinos:  #corroboramos que exista el ID ingresado
                    modificar = (input("Ingrese lo que desea modificar del destino P(pais)/C(ciudad)/K(costo): ")).upper()
                    if modificar=="P":  #opcion para modificar el pais
                     nuevo_pais=input(f"Ingrese el nuevo país del destino {id_destino}: ")
                     destinos[id_destino]['pais'] = nuevo_pais
                     print(f"Modificando destino {id_destino}")
                     print("Destino modificado correctamente.")
                    elif modificar=="C":  #opcion para modificar la ciudad
                     nueva_ciudad=input(f"Ingrese la nueva ciudad del destino {id_destino}: ")
                     destinos[id_destino]['ciudad'] = nueva_ciudad
                     print(f"Modificando destino {id_destino}")
                     print("Destino modificado correctamente.")
                    elif modificar=="K":  #opcion para modificar el costo
                     nuevo_precio=input(f"Ingrese el nuevo precio del destino {id_destino}: ")
                     destinos[id_destino]['costo'] = nuevo_precio
                     print(f"Modificando destino {id_destino}")
                     print("Destino modificado correctamente.")
                    else:
                       print("\nError: Opción inválida. Debe elegir P, C o K.")
                else:
                    print("El ID que desea modificar no existe.")
                break
            elif opcion_funcion == 3:  #opcion para eliminar un destino
                id_destino=input("Ingrese el ID del destino que desea eliminar: ")
                if id_destino in destinos:  #corroboramos que exista el ID ingresado
                   print(f"Eliminando destino {id_destino}")
                   del destinos[id_destino]
                   print("Destino eliminado correctamente.")
                else:
                   print("El destino ingresado no existe")
                break
            elif opcion_funcion == 4:   #opcion para regresar al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

