from clientes import gestionar_clientes

from destinos import gestionar_destinos

from ventas import gestionar_ventas

from ventas import consultar_ventas

from arrepentimiento import boton_arrepentimiento

from reportes import ver_reporte_general

from reportes import acerca_del_sistema



#funcion para mostrar el menu
   
import sys

clientes={}
destinos={}
ventas={}

def menu():

    #aca comienza el programa
    print("---Bienvenido a la web de SkyRoute---")


    while True:  # Bucle principal del menu
        print("""\n--- Menú Principal ---
    1. Gestionar Clientes
    2. Gestionar Destinos
    3. Gestionar Ventas
    4. Consultar Ventas
    5. Botón de Arrepentimiento
    6. Ver Reporte General
    7. Acerca del Sistema
    8. Salir""")
        try:
            opcion = int(input("Seleccione una opción (1-8): "))  #aseguramos que ingrese un num entero
            if opcion == 1:
                gestionar_clientes(clientes)
            elif opcion == 2:
                gestionar_destinos(destinos)
            elif opcion == 3:
                gestionar_ventas(ventas, clientes, destinos)
            elif opcion == 4:
                consultar_ventas(ventas)
            elif opcion == 5:
                boton_arrepentimiento(ventas)
            elif opcion == 6:
                ver_reporte_general()
            elif opcion == 7:
                acerca_del_sistema()
            elif opcion == 8:
                print("Gracias por utilizar nuestro servicio")
                break
            else:
                print("Opcion invalida.")   
        except ValueError:
            print(" Error: Por favor, ingrese un número válido.")


menu()