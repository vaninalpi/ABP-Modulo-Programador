# Función para gestionar los clientes

def gestionar_clientes(clientes):
    while True:     #mostramos las opciones del submenu
        print("""\n>>> Gestión de Clientes<<<
        1. Ver clientes  
        2. Registrar cliente
        3. Modificar cliente
        4. Eliminar cliente
        5. Volver al Menú Principal""")
       
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:    #opcion para ver los clientes
                print("Mostrando lista de clientes...\n")
                for cuit, datos in clientes.items(): # Iteramos sobre los items del diccionario
                    print(f"\nCUIT: {cuit} - RAZON SOCIAL: {datos['razon_social']} - CONTACTO: {datos['contacto']}") 
                print("\nClientes mostrados correctamente.")
                break
            elif opcion_funcion == 2:  #opcion para registrar un cliente
                cuit_cliente=int(input("\nIngrese el CUIT del cliente: "))
                if cuit_cliente in clientes:   #corroboramos que no existe el cuit que ingresa
                    print("\nEl cliente ya existe en la base de datos.")
                else:
                    razon_social=input("\nIngrese la razon social del cliente: ")
                    contacto_cliente=input("\nIngrese el correo del contacto: ")
                    clientes.update({cuit_cliente: {     #agregamos al diccionario teniendo como identificador el cuit
                        "razon_social": razon_social,
                        "contacto": contacto_cliente}
                        })
                    print(f""">>Cliente registrado como:  
                    \nRazon Social: {razon_social}
                    \nCUIT: {cuit_cliente}
                    \nCorreo de contacto: {contacto_cliente}
                    """)  #mostramos los datos del cliente registrado
                break
            elif opcion_funcion == 3:  # Opción para modificar un cliente
                cuit_cliente = int(input("Ingrese el CUIT del cliente que desea modificar: "))
                if cuit_cliente in clientes:  #corroboramos que exista el cuit ingresado
                    contacto_viejo = clientes[cuit_cliente]['contacto']
                    print(f"\nEl contacto actual del cliente con CUIT {cuit_cliente} es: {contacto_viejo}")  #mostramos contacto viejo
        
                    contacto_nuevo = input("\nIngrese el nuevo contacto del cliente: ") #ingresamos nuevo contacto
                    print("\nModificando cliente...")
                    clientes[cuit_cliente]['contacto'] = contacto_nuevo
                    print(f"\nCliente con CUIT {cuit_cliente} modificado correctamente.")
                    print(f"Nuevo contacto registrado: {contacto_nuevo}")  #mostramos nuevo contacto
                else:
                    print("\nError: El CUIT ingresado no existe en la base de datos.")  #avisamos que el cuit ingresado no existe
                break
            elif opcion_funcion == 4:  # Opción para eliminar un cliente
                cuit_cliente = int(input("Ingrese el CUIT del cliente que desea eliminar: "))
                if cuit_cliente in clientes:  #corroboramos que exista el cuit ingresado
                    print("\nEliminando cliente...")
                    del clientes[cuit_cliente]  #procede a eliminar ese cuit del dicc clientes
                    print(f"\nCliente con CUIT {cuit_cliente} eliminado correctamente.")
                else:
                    print("\nError: El CUIT ingresado no existe en la base de datos.")  #damos aviso que no existe ese cuit
                break
            elif opcion_funcion == 5:  #opcion para regresar al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

