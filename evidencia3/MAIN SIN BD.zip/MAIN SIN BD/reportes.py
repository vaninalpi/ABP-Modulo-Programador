# Función para mostrar el reporte general
def ver_reporte_general():
    while True:   #opciones dentro del menu de reporte general
        print("""\n>>> Reporte General<<<  
        1. Ver reporte general
        2. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:  #opcion para mostrar el reporte general
                print("El reporte general no esta disponible en este momento")
                print("¡Lo esperamos pronto!")
                break
            elif opcion_funcion == 2:  #opcion para volver al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

# Función para mostrar acerca del sistema
def acerca_del_sistema():
    while True:
        print("""\n>>> SkyRoute - Sistema de Gestión de Pasajes<<<
        Versión 2.0 (Programa a base de diccionarios en Python)
        
        Desarrollado por el grupo 25 "Rio 3 y zona":
        #Leila Selena Castillo   DNI: 43134859
        #Gabriel Cavallo         DNI: 28103891
        #Paulina González        DNI: 38107047
        #Vanina Leticia Pi       DNI: 39908554
        #Favio Villalon          DNI: 39172727
        
        El sistema se encuentra en constante desarrollo
        ¡Gracias por elegirnos!
        \n1. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))  
            if opcion_funcion == 1:  #opcion de volver al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

