import mysql

# Función para gestionar los destinos

def gestionar_destinos(conn):
    cursor = conn.cursor()
    while True:             #mostramos las opciones 
        print("""\n>>> Gestión de Destinos<<<
        1. Registrar destino
        2. Modificar destino
        3. Eliminar destino
        4. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1: #opcion para registrar un destino nuevo
                try:
                    id_destino=input("Ingrese el ID del destino: ")
                    ciudad_destino=input("Ingrese la ciudad del destino: ")
                    pais_destino=input("Ingrese el pais del destino: ")
                    costo_destino=input("Ingrese el costo de base del destino: ")
                    cursor.execute("INSERT INTO destinos (id_destino, ciudad_destino, pais_destino, costo_base_destino) VALUES(%s,%s,%s,%s)",(id_destino,ciudad_destino,pais_destino,costo_destino))
                    conn.commit()
                    print(f""">>Destino registrado como:
                    \nID: {id_destino}     
                    \nCiudad: {ciudad_destino}
                    \nPais: {pais_destino}
                    \nCosto base del viaje:  {costo_destino}
                    """)   #acabamos de mostrar los datos del nuevo destino registrado
                    break
                except mysql.connector.Error as err:  #para capturar el error de que haya registros duplicados
                    if err.errno == 1062:  # Código de error para entradas duplicadas
                        print(f"Error: Ya existe un destino con id_destino {id_destino}")  #avisamos que ya existe ese destino
                    else:
                        print(f"Error al registrar destino: {err}")
                    conn.rollback()   #deshace los cambios si ocurre algun error en el proceso
            elif opcion_funcion == 2:   #opcion para modificar un destino
                id_destino=input("Ingrese el ID del destino que desea modificar: ")
                modificar = (input("Ingrese lo que desea modificar del destino P(pais)/C(ciudad)/K(costo): ")).upper()
                if modificar=="P":  #opcion para modificar el pais del destino
                    nuevo_pais=input(f"Ingrese el nuevo país del destino {id_destino}: ")
                    cursor.execute("UPDATE destinos SET pais_destino=%s WHERE id_destino=%s",(nuevo_pais,id_destino))
                    conn.commit()
                    print(f"Modificando destino {id_destino}")
                    print("Destino modificado correctamente.")
                elif modificar=="C":   #opcion para modificar la ciudad del destino
                    nueva_ciudad=input(f"Ingrese la nueva ciudad del destino {id_destino}: ")
                    cursor.execute("UPDATE destinos SET ciudad_destino=%s WHERE id_destino=%s",(nueva_ciudad,id_destino))
                    conn.commit()
                    print(f"Modificando destino {id_destino}")
                    print("Destino modificado correctamente.")
                elif modificar=="K":   #opcion para modificar el costo del destino
                    nuevo_precio=input(f"Ingrese el nuevo precio del destino {id_destino}: ")
                    cursor.execute("UPDATE destinos SET costo_base_destino=%s WHERE id_destino=%s",(nuevo_precio,id_destino))
                    conn.commit()
                    print(f"Modificando destino {id_destino}")
                    print("Destino modificado correctamente.")
            elif opcion_funcion == 3:    #opcion para eliminar un destino
                id_destino=input("Ingrese el ID del destino que desea eliminar: ")
                print(f"Eliminando destino {id_destino}")
                cursor.execute("DELETE FROM destinos WHERE id_destino=%s",(id_destino,))
                conn.commit()
                print("Destino eliminado correctamente.")
                break
            elif opcion_funcion == 4:   #opcion para volver al manu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

