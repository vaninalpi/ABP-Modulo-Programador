# Función para acceder al botón de arrepentimiento

import mysql
from datetime import datetime,timedelta


def boton_arrepentimiento(conn):
    cursor = conn.cursor()
    while True:
        print("""\n>>> Botón de Arrepentimiento<<<
        1. Cancelar compra
        2. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:
                id_venta = input("Ingrese el ID de la venta que desea cancelar: ")

                #Obtener y mostrar la fecha de la compra antes de continuar
                cursor.execute("SELECT fecha_venta FROM ventas WHERE id_venta=%s", (id_venta,))
                resultado_fecha = cursor.fetchone()

                if not resultado_fecha:
                    print(f"No se encontró ninguna venta con el ID: {id_venta}. Intente nuevamente.")
                    continue  #Permitir que el usuario vuelva a ingresar un ID válido
                
                fecha_venta = resultado_fecha[0]  
                print(f"La fecha de compra registrada para el ID {id_venta} es: {fecha_venta}")

                #Validación de fecha ingresada por el usuario
                while True:
                    try:  
                        fecha = input("Ingrese la fecha de hoy (formato YYYY-MM-DD): ")
                        fecha_hoy = datetime.strptime(fecha, "%Y-%m-%d").date()
                        break  
                    except ValueError:
                        print("Formato inválido. Use YYYY-MM-DD (Ejemplo: 2025-06-03).")

                #Calcular límite de cancelación
                fecha_limite = fecha_venta + timedelta(days=5)

                #Validación para permitir la cancelación dentro de los 5 días
                if fecha_hoy <= fecha_limite:
                    fecha_anulacion = datetime.now()
                    cursor.execute("UPDATE ventas SET id_estado = 2, fecha_anulacion = %s WHERE id_venta=%s", (fecha_hoy, id_venta))
                    conn.commit()
                    print(f"La compra con ID {id_venta} ha sido cancelada correctamente el {fecha_anulacion.strftime('%Y-%m-%d %H:%M:%S')}.")
                else:
                    print(f"No es posible cancelar la venta. Han pasado más de 5 días desde la fecha de compra ({fecha_venta}).")

            elif opcion_funcion == 2:
                print("Regresando al menú principal...")
                break

            else:
                print("Opción fuera de rango. Intente nuevamente.")

        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")


