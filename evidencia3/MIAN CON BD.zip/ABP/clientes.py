# Función para gestionar los clientes
import mysql


def gestionar_clientes(conn):
    cursor = conn.cursor()
    while True:                 #mostramos las opciones disponibles en este submenu
        print("""\n>>> Gestión de Clientes<<<
        1. Ver clientes  
        2. Registrar cliente
        3. Modificar cliente
        4. Eliminar cliente
        5. Volver al Menú Principal""")
       
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:
                print("Mostrando lista de clientes...")
                cursor.execute("SELECT cuit_cliente,razon_social FROM clientes") #Seleccionamos de la tabla clientes 
                for cliente in cursor:                                          #Iteramos sobre el cursor, que devuelve una fila a la vez en forma de tuplas
                    print(f"CUIT:{cliente[0]} - RAZON SOCIAL:{cliente[1]}")
                print("Clientes mostrados correctamente.")
                break
            elif opcion_funcion == 2:
                try:                    #pedimos los datos para que registre al cliente
                    razon_social=input("Ingrese la razon social del cliente: ")
                    cuit_cliente=int(input("Ingrese el CUIT del cliente: "))
                    contacto_cliente=input("Ingrese el correo del contacto: ")
                    cursor.execute("INSERT INTO clientes (cuit_cliente, razon_social) VALUES(%s,%s)",(cuit_cliente,razon_social))
                    cursor.execute("INSERT INTO contactos (cuit_cliente, correo_cliente) VALUES (%s,%s)",(cuit_cliente,contacto_cliente))
                    conn.commit()       #esta linea confirma los cambios a realizar en la base de datos
                    print(f""">>Cliente registrado como:
                \nRazon Social: {razon_social}
                \nCUIT: {cuit_cliente}
                \nCorreo de contacto: {contacto_cliente}
                """) #acabamos de mostrar los datos del nuevo registro
                except mysql.connector.Error as err:  #para capturar el error de que haya registros duplicados
                    if err.errno == 1062:  # Código de error para entradas duplicadas
                        print(f"Error: Ya existe un cliente con CUIT {cuit_cliente}")
                    else:
                        print(f"Error al registrar cliente: {err}")
                    conn.rollback()
                break
            elif opcion_funcion == 3: #opcion para modificar el cliente
                cuit_cliente=int(input("Ingrese el CUIT del cliente que desea modificar: "))
                contacto_nuevo=input("Ingrese el nuevo contacto del cliente: ")
                print("Modificando cliente...")
                cursor.execute("UPDATE contactos SET correo_cliente=%s WHERE cuit_cliente=%s",(contacto_nuevo,cuit_cliente))
                conn.commit()
                print(f"Cliente con CUIT:{cuit_cliente} modificado correctamente.")
                break
            elif opcion_funcion == 4:  #opcion para eliminar un cliente
                cuit_cliente=int(input("Ingrese el CUIT del cliente que desea eliminar: "))
                print("Eliminando cliente...")
                cursor.execute("DELETE FROM clientes WHERE cuit_cliente=%s",(cuit_cliente,))
                conn.commit()
                print(f"Cliente con CUIT:{cuit_cliente} eliminado correctamente.")
                break
            elif opcion_funcion == 5:  #opcion para regresar al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

    