#Programa de Python para simular una aplicacion de una empresa de viajes con un menu que tiene como 
# finalidad establecer las bases funcionales del sistema propuesto en la evidencia, ofreciendo un menú 
# interactivo que simula el funcionamiento deseado para una navegacion con diferentes opciones para el
# usuario, y asi poder administrar los datos a manipular.


# Para el uso de este programa lo primero que necesitamos tener es visual studio code para
# poder ejecutar el programa. El mismo puede instalarse desde su pagina oficial.
# Para tener el programa se debera descargarlo de la fuente que lo provea (en este caso un miembro del 
# grupo). Una vez descargado se debera abrir Visual Studio Code y abrir el programa previamente 
# descargado para poder ejecutarlo y comenzar a usarlo.
# Para usarlo solo deberemos darle en la opcion de Run Python File la cual se encuentra en la parte 
# superior derecha (tiene forma de triangulo) y ya comenzar a seleccionar las opciones disponibles que 
# te ofrece el programa.


# INTEGRANTES DEL GRUPO:
#Leila Selena Castillo   DNI: 43134859
#Gabriel Cavallo         DNI: 28103891
#Paulina González        DNI: 38107047
#Vanina Leticia Pi       DNI: 39908554
#Favio Villalon          DNI: 39172727

#importamos las funciones que vamos a usar

from clientes import gestionar_clientes

from destinos import gestionar_destinos

from ventas import gestionar_ventas

from ventas import consultar_ventas

from arrepentimiento import boton_arrepentimiento

from reporte_sistema import ver_reporte_general

from reporte_sistema import acerca_del_sistema

from abrir_base import conexion


#funcion para mostrar el menu
   
import sys

def menu():

    #aca comienza el programa

    print(" Conectando a la base de datos...")

    conn = conexion()
    print(f"Estado de la conexión inicial: {conn}")
    if not conn:
        print("No se pudo establecer conexión con la base de datos.")
        print("Finalizando el programa.")
        return  # Cortamos la ejecución sin error


    print("---Bienvenido a la web de SkyRoute---")


    while True:  # Bucle principal del menu
        print("""\n--- Menú Principal ---
    1. Gestionar Clientes
    2. Gestionar Destinos
    3. Gestionar Ventas
    4. Consultar Ventas
    5. Botón de Arrepentimiento
    6. Ver Reporte General
    7. Acerca del Sistema
    8. Salir""")
        try:
            opcion = int(input("Seleccione una opción (1-8): "))  #aseguramos que ingrese un num entero
            if opcion == 1:
                gestionar_clientes(conn)
            elif opcion == 2:
                gestionar_destinos(conn)
            elif opcion == 3:
                gestionar_ventas(conn)
            elif opcion == 4:
                consultar_ventas(conn)
            elif opcion == 5:
                boton_arrepentimiento(conn)
            elif opcion == 6:
                ver_reporte_general()
            elif opcion == 7:
                acerca_del_sistema()
            elif opcion == 8:
                print("Gracias por utilizar nuestro servicio")
                break
            else:
                print("Opcion invalida.")   
        except ValueError:
            print(" Error: Por favor, ingrese un número válido.")  

    conn.close()  #cerramos la conexion con la BD
    print("Conexión cerrada.")

#inicio del programa llamando la funcion menu
menu()

