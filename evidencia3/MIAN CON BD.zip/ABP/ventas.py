# Función para gestionar las ventas
import mysql
from datetime import datetime

def gestionar_ventas(conn):
    cursor = conn.cursor()
    while True:         #mostramos opciones disponibles
        print("""\n>>> Gestión de Ventas<<<
        1. Registrar venta
        2. Ver estado de la venta
        3. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:
                while True:
                    id_venta = input("Ingrese el ID de la venta: ")
                        # Verificar si el ID de venta ya existe
                    cursor.execute("SELECT COUNT(*) FROM ventas WHERE id_venta = %s", (id_venta,))
                    venta_existente = cursor.fetchone()[0]  #busca solo la fila con los datos que le pedimos

                    if venta_existente > 0:  
                     print(f"Error: Ya existe una venta con ID {id_venta}. Ingrese otro ID.")
                    else:
                     break  # Si el ID es único, salimos del bucle

                cuit_cliente=input("Ingrese el CUIT del cliente que realiza la compra: ")
                 #Verificar si el cliente existe antes de registrar la venta
                cursor.execute("SELECT COUNT(*) FROM clientes WHERE cuit_cliente = %s", (cuit_cliente,))
                existe_cliente = cursor.fetchone()[0]

                if existe_cliente == 0:  # Si no existe en la base de datos
                    print(f"Error: El cliente con CUIT {cuit_cliente} no está registrado.")
                    print("Por favor, regístrelo en la base de datos antes de realizar la venta.")
                    return  #Se detiene la ejecución de la función

                while True:
                     id_vuelo = input("Ingrese el ID del vuelo: ")

                    # Verificar si el ID de vuelo existe en la tabla vuelos
                     cursor.execute("SELECT COUNT(*) FROM vuelos WHERE id_vuelo = %s", (id_vuelo,))
                     vuelo_existente = cursor.fetchone()[0]

                     if vuelo_existente == 0:  
                      print(f"Error: El vuelo con ID {id_vuelo} no existe.")
                      print("Por favor, revise el catálogo de vuelos disponibles antes de continuar.")
                     else:
                      break  # Si el vuelo existe, salir del bucle
                while True:
                    nombre_asiento = input("Ingrese el ID del asiento: ")
    
                    # Verificar si el asiento existe en la tabla `asiento`
                    cursor.execute("SELECT COUNT(*) FROM asiento WHERE id_vuelo = %s AND nombre_asiento = %s", (id_vuelo, nombre_asiento))
                    asiento_existente = cursor.fetchone()[0]

                    if asiento_existente == 0:
                        print(f"Error: El asiento {nombre_asiento} en el vuelo {id_vuelo} no existe.")
                        print("Revise el catálogo de asientos disponibles para el vuelo y vuelva a intentarlo.")
                    else:
                        break  # Si el asiento es válido, salir del bucle y continuar con el registro de la venta
        
                while True:
                    try:
                        fecha = input("Ingrese la fecha de venta (formato YYYY-MM-DD): ")
                        fecha_venta = datetime.strptime(fecha, "%Y-%m-%d").date()
                        break  # Si la fecha es válida, salimos del bucle
                    except ValueError:
                        print("Formato inválido. Usá YYYY-MM-DD (por ejemplo: 2025-06-03). Inténtalo de nuevo.")
                id_estado = 1
                fecha_anulacion=None
                try:    #cargamos los datos a la base de datos
                    cursor.execute("INSERT INTO ventas (id_venta, cuit_cliente,id_vuelo,nombre_asiento,fecha_venta,id_estado,fecha_anulacion) VALUES (%s,%s,%s,%s,%s,%s,%s)",(id_venta,cuit_cliente,id_vuelo,nombre_asiento,fecha_venta,id_estado,fecha_anulacion))
                    conn.commit()

                    cursor.fetchall()

                    cursor.execute("SELECT id_destino FROM vuelos WHERE id_vuelo=%s", (id_vuelo,))
                    resultado_destino = cursor.fetchone()
                    id_destino = resultado_destino[0] if resultado_destino else "No encontrado"

                    cursor.execute("SELECT tipo_estado FROM estado WHERE id_estado=%s", (id_estado,))
                    resultado_estado = cursor.fetchone()
                    estado_venta = resultado_estado[0] if resultado_estado else "No encontrado" 
                    print(f""">>Se registra nueva venta:
                        \nCliente: {cuit_cliente}
                        \nDestino con ID: {id_destino}
                        \nFecha de la venta: {fecha_venta}
                        \nID de la venta: {id_venta}
                        \nEstado de la venta: {estado_venta}
                        """) #mostramos la nueva venta
                except mysql.connector.Error as err:  #para capturar el error de que haya registros duplicados
                    if err.errno == 1062:  # Código de error para entradas duplicadas
                        print(f"Error: Ya existe una venta con ID: {id_venta}")
                    else:
                        print(f"Error al registrar la venta: {err}")
                    conn.rollback()
                break
                
            elif opcion_funcion == 2:   #opcion para ver el estado de una venta
                id_venta=input("Ingrese el ID de la venta que desea ver el estado: ")
                try:
                    cursor.execute("SELECT e.tipo_estado FROM ventas v JOIN estado e ON v.id_estado = e.id_estado WHERE v.id_venta = %s;",(id_venta,))
                    resultado = cursor.fetchone()
                    if resultado:
                        print(f"El estado de la venta: {id_venta}, es {resultado[0]}")
                    else:
                        print(f"No se encontró la venta con ID: {id_venta}")
                except mysql.connector.Error as err:
                    print(f"Error al consultar el estado: {err}")
                break
            elif opcion_funcion == 3:   #opcion para volver al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")


# Función para consultar las ventas
def consultar_ventas(conn):
    cursor = conn.cursor()
    while True:   #opciones disponibles para la consulta de ventas
        print("""\n>>> Consulta de Ventas<<< 
        1. Consultar ventas
        2. Volver al Menú Principal""")
        
        try:
            opcion_funcion = int(input("Seleccione una opción: "))
            if opcion_funcion == 1:  #opcion para mostrar el registro de todas las ventas
                print("Mostrando historial de ventas...")
                try:
                    cursor.execute("SELECT id_venta, cuit_cliente,id_vuelo,nombre_asiento,fecha_venta,id_estado,fecha_anulacion FROM ventas")
                    for venta in cursor:    #para cada venta que encuentre en la BD mostrara los datos
                        print(f"ID VENTA:{venta[0]} - CUIT CLIENTE:{venta[1]} - ID VUELO:{venta[2]} - ASIENTO:{venta[3]} - FECHA VENTA:{venta[4]} - ID ESTADO:{venta[5]} - FECHA ANULACION:{venta[6]}")
                    print("Ventas mostradas correctamente.")
                except mysql.connector.Error as err:
                    print(f"Error al consultar ventas: {err}")
                break
            elif opcion_funcion == 2:   #opcion para volver al menu principal
                print("Regresando al menú principal...")
                break
            else:
                print("Opción fuera de rango. Intente nuevamente.")
        except ValueError:
            print("Entrada no válida. Por favor, ingrese un número.")

