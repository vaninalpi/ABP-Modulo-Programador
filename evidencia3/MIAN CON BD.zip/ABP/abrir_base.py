import mysql.connector
from mysql.connector import Error

#funcion para conectarse a la base de datos
def conexion():
    try:
        conn = mysql.connector.connect(
            host='127.0.0.1',           #datos necesarios
            user='root',                #para conectarse
            password='12345',           #a la base de
            database='aerolinea'        #datos
        )

        #damos aviso si se pudo conectar o no a la BD
        if conn.is_connected():
            print("Conexión exitosa a la base de datos.")
            return conn

    except Error as er:
        print(f"Error al conectar la base de datos: {er}")