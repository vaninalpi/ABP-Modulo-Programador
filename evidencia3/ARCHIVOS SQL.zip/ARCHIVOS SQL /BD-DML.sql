--Sentencias SQL (lenguaje DML) para insertar datos de ejemplo en cada una de las tablas creadas

-- Datos para la tabla clientes:
INSERT INTO `clientes` (`cuit_cliente`, `razon_social`) VALUES
	(20394483517, 'ipem385'),
	(27399085549, 'ipem438'),
    (20365289787, 'ipem438');

-- Datos para la tabla contactos, teniendo presente que deben existir cuit_clientes para ingresar tupla:
INSERT INTO `contactos` (`cuit_cliente`, `correo_cliente`) VALUES
	(27399085549, 'vaninalpi@gmail.com'),
	(20394483517, 'joaquin@gmail.com'),
    (20365289787, 'juan@gmail.com');

-- Datos para la tabla destinos:
INSERT INTO `destinos` (`id_destino`, `ciudad_destino`, `pais_destino`, `costo_base_destino`) VALUES
	(1, 'floripa', 'brasil', 20000.00),
	(2, 'cordoba', 'argentina', 13000.00),
    (3, 'buenos aires', 'argentina', 10000.00);


-- Datos para la tabla vuelos, teniendo en cuenta que debe existir id_destino para ingresar tupla: 
INSERT INTO `vuelos` (`id_vuelo`, `id_destino`, `fecha_vuelo`, `hora_vuelo`) VALUES
	(1, 1, '2010-12-25', '12:00:00'),
	(2, 2, '2010-12-25', '13:00:00'),
	(3, 1, '2011-12-25', '14:30:00');

-- Datos para la tabla vuelos, teniendo en cuenta que debe existir id_vuelo para ingresar tupla: 
INSERT INTO `asiento` (`id_vuelo`, `nombre_asiento`, `clase_asiento`, `precio`) VALUES
	(1, 'A3', 'turista', 10000.00),
	(1, 'A4', 'turista', 10000.00),
	(2, 'P3', 'premium', 20000.00);

-- Datos para la tabla ventas, teniendo en cuenta que debe existir cuit_cliente, id_vuelo, nombre_asiento, para poder ingresar tupla:
INSERT INTO `ventas` (`id_venta`, `cuit_cliente`, `id_vuelo`, `nombre_asiento`, `fecha_venta`, `id_estado`, `fecha_anulacion`) VALUES
	(1, 20394483517, 1, 'A4', '2025-10-10', 2, '2025-10-15'),
	(2, 27399085549, 1, 'A3', '2025-10-10', 1, NULL),
	(3, 20394483517, 2, 'P3', '2025-12-12', 1, NULL);

-- Datos para la tabla estado:
INSERT INTO `estado` (`id_estado`, `tipo_estado`) VALUES
	(1, 'activo'),
	(2, 'cancelado');





