-- Listar todos los clientes.
SELECT * FROM clientes;

-- Mostrar las ventas realizadas en una fecha específica. 
SELECT * FROM ventas WHERE fecha_venta='2025-10-10';

-- Obtener la última venta de cada cliente y su fecha. 
SELECT cuit_cliente, MAX(fecha_venta) AS ultima_compra --selecciona columnas, en el caso de fecha (usamos MAX porque es la fecha más alta)
FROM ventas 
GROUP BY cuit_clientes --Agrupamos todas las ventas por cliente para calcular la fecha máxima
ORDER BY ultima_compra DESC; --Ordena los resultados con las fechas más recientes primero

--Listar todos los destinos que empiezan con “S”
SELECT id_destino,ciudad_destino,pais_destino,costo_base_destino FROM destinos WHERE ciudad_destino LIKE 'S%'

--Mostrar cuántas ventas se realizaron por país. 
SELECT d.pais_destino AS pais, COUNT(v.id_venta) AS total_ventas -- seleccionamos datos, con COUNT contamos el numero de ventas
FROM ventas v
JOIN vuelos vu ON v.id_vuelo=vu.id_vuelo -- unimos ventas con vuelos mediante id_vuelo
JOIN destinos d ON vu.id_destino=d.id_destino -- unimos vuelos con destinos mediante id_destino
GROUP BY d.pais_destino; -- agrupamos los resultados por país