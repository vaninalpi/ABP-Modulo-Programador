-- crear base de datos aerolineas
CREATE DATABASE IF NOT EXISTS `aerolinea`;
USE `aerolinea`;

-- Creando tabla clientes, con clave primaria cuit_cliente
CREATE TABLE IF NOT EXISTS `clientes` (
  `cuit_cliente` bigint(20) NOT NULL DEFAULT 0,
  `razon_social` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`cuit_cliente`)
);

-- Creando tabla contactos, con clave foranea cuit_cliente referencia a tabla clientes
CREATE TABLE IF NOT EXISTS `contactos` (
  `cuit_cliente` bigint(20) DEFAULT NULL,
  `correo_cliente` varchar(50) DEFAULT NULL,
  KEY `FK__clientes` (`cuit_cliente`),
  CONSTRAINT `FK_contactos_clientes` FOREIGN KEY (`cuit_cliente`) REFERENCES `clientes` (`cuit_cliente`) ON DELETE CASCADE ON UPDATE NO ACTION
);

-- Creando tabla destinos con clave primaria id_destino
CREATE TABLE IF NOT EXISTS `destinos` (
  `id_destino` int(11) NOT NULL,
  `ciudad_destino` varchar(50) DEFAULT NULL,
  `pais_destino` varchar(50) DEFAULT NULL,
  `costo_base_destino` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_destino`)
);

-- Creando tabla vuelos, con clave primaria id_vuelo, y clave foranea id_destino referencia a tabla destinos
CREATE TABLE IF NOT EXISTS `vuelos` (
  `id_vuelo` int(11) NOT NULL,
  `id_destino` int(11) NOT NULL,
  `fecha_vuelo` date NOT NULL,
  `hora_vuelo` time NOT NULL,
  PRIMARY KEY (`id_vuelo`),
  KEY `FK__destinos` (`id_destino`),
  CONSTRAINT `FK__destinos` FOREIGN KEY (`id_destino`) REFERENCES `destinos` (`id_destino`) ON DELETE CASCADE ON UPDATE NO ACTION
);


-- Creando tabla asientos, donde su clave primaria es compuesta id_vuelo que es clave foranea referenciada a la tabla vuelos y una clave propia nombre_asiento
CREATE TABLE IF NOT EXISTS `asiento` (
  `id_vuelo` int(11) NOT NULL,
  `nombre_asiento` varchar(5) NOT NULL,
  `clase_asiento` varchar(50) NOT NULL,
  `precio` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id_vuelo`,`nombre_asiento`),
  CONSTRAINT `FK__vuelos` FOREIGN KEY (`id_vuelo`) REFERENCES `vuelos` (`id_vuelo`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;


-- Creando tabla estado, con clave primaria id_estado
CREATE TABLE IF NOT EXISTS `estado` (
  `id_estado` int(11) NOT NULL,
  `tipo_estado` char(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_estado`)
);


-- Creando tabla ventas, con clave primaria ventas, pero diversas claves foraneas. 
CREATE TABLE IF NOT EXISTS `ventas` (
  `id_venta` int(11) NOT NULL,
  `cuit_cliente` bigint(20) DEFAULT NULL,
  `id_vuelo` int(11) NOT NULL DEFAULT 0,
  `nombre_asiento` varchar(5) NOT NULL DEFAULT '',
  `fecha_venta` date NOT NULL,
  `id_estado` int(11) NOT NULL,
  `fecha_anulacion` date DEFAULT NULL,
  PRIMARY KEY (`id_venta`),
  UNIQUE KEY `venta_asiento_vuelo` (`id_vuelo`, `nombre_asiento`),
  KEY `FK_ventas_clientes` (`cuit_cliente`),
  KEY `FK_ventas_asiento` (`id_vuelo`,`nombre_asiento`),
  KEY `FK_ventas_estado` (`id_estado`),
  CONSTRAINT `FK_ventas_asiento` FOREIGN KEY (`id_vuelo`, `nombre_asiento`) REFERENCES `asiento` (`id_vuelo`, `nombre_asiento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ventas_clientes` FOREIGN KEY (`cuit_cliente`) REFERENCES `clientes` (`cuit_cliente`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_ventas_estado` FOREIGN KEY (`id_estado`) REFERENCES `estado` (`id_estado`) ON DELETE NO ACTION ON UPDATE NO ACTION
);